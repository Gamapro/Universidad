﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinaProjectSalesApp { 
    public abstract class TruckFactory
    {
        public abstract Truck FactoryCreate();
    }
}
